<? include ('includes/headA.php') ?>

	<div id="body">


<!-- ------- Main Content Start ---------------------------------------------------------- -->    
    <div id="mainCol">
	<h5><a href="index.php">home </a>> <a href="featured-lakefront.php">featured lakefront </a>> <a href="featured-lakefront-detail.php">featured lakefront detail</a></h5>
<br />
    <table style="background-color:#b0a383; width:100%; border: 1px solid #6A5B48;" cellpadding="0" cellspacing="0">
       <tr>
           <td colspan="6"><h3> Lowest Priced House on Lake Keystone; Odessa / Tampa</h3></td>            
       </tr>
        
        <tr>
            <th class="leftBorder" align="center">Acres</td>
            <th class="border" align="center">Sqft</td>
            <th class="border" align="center">Beds</td>
            <th class="border" align="center">Baths</td>
            <th class="border" align="center">Garage</td>
            <th class="border" align="center">Pool</td>
        </tr>
        <tr>
            <td class="leftBorder" align="center">1 - 2</td>
            <td class="border" align="center">2480</td>
            <td class="border" align="center">4</td>
            <td class="border" align="center">2</td>
            <td class="border" align="center">2</td>
            <td class="border" align="center">Yes</td>
        </tr> 
        
        <tr>
            <td colspan="6" style="text-align: center; padding: 10px;">
            <h4>Click an image below to open the slideshow. <br>Mouseover Image to View Next and Previous Slides</h4>
            </td>                       
        </tr>  
        
        <tr>
            <td colspan="6" style="text-align: center; padding: 10px;">
            <ul class="thumbs">
				<!-- ////////////// USE rel="lightbox[leaves]" ///// a set of related images that you would like to group //// -->
            	<!-- <li><a href="images/image-1.jpg" rel="lightbox[leaves]"><img width="80" src="images/thumb-1.jpg" /></a></li> -->
            	<li><a href="images/image-1.jpg" rel="lightbox[leaves]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb-1.jpg"  alt="Plants: image 1 0f 5 thumb" /></a></li>
            	<li><a href="images/image-1.jpg" rel="lightbox[leaves]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb-2.jpg" alt="Plants: image 2 0f 5 thumb" /></a></li>
            	<li><a href="images/image-1.jpg" rel="lightbox[leaves]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb-3.jpg" alt="Plants: image 3 0f 5 thumb" /></a></li>
            	<li><a href="images/image-1.jpg" rel="lightbox[leaves]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb-4.jpg" alt="Plants: image 4 0f 5 thumb" /></a></li>
            	<li><a href="images/image-1.jpg" rel="lightbox[leaves]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb-5.jpg" alt="Plants: image 5 0f 5 thumb" /></a></li>
            </ul>
            
            <ul class="thumbs">
            	<li><a href="images/Autumnslisting.jpg" rel="lightbox[Odessa Property]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb_01.jpg" alt="Odessa Property: image 1 0f 5 thumb" /></a></li>
            	<li><a href="images/Autumnslisting.jpg" rel="lightbox[Odessa Property]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb_02.jpg" alt="Odessa Property: image 2 0f 5 thumb" /></a></li>
            	<li><a href="images/Autumnslisting.jpg" rel="lightbox[Odessa Property]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb_03.jpg" alt="Odessa Property: image 3 0f 5 thumb" /></a></li>
            	<li><a href="images/Autumnslisting.jpg" rel="lightbox[Odessa Property]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb_04.jpg" alt="Odessa Property: image 4 0f 5 thumb" /></a></li>
            	<li><a href="images/Autumnslisting.jpg" rel="lightbox[Odessa Property]" title="Mouseover image to click the 'previous' or 'next' buttons."><img width="80" src="images/thumb_05.jpg" alt="Odessa Property: image 5 0f 5 thumb" /></a></li>
            </ul>
            	
            
            </td>                       
        </tr>        
        
        <tr>

            <td colspan="6" style="width:500px;padding:0px;">
            <table align="center" style="width:500px;" border="0">
                <tr>
                   <td style="text-align:right;font-size:small;font-weight:bold;">Offered at:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;"><span class="price">$795,000</span></td>
                   <td style="text-align:right;font-size:small;font-weight:bold;">Lake:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;"><a href="#">Lake Keystone</a></td>

                </tr>
                <tr>
                   <td style="text-align:right;font-size:small;font-weight:bold;">Status:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;">Active</td>
                   <td style="text-align:right;font-size:small;font-weight:bold;">City:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;">Odessa</td>
                </tr>

                <tr>
                   <td style="text-align:right;font-size:small;font-weight:bold;">Virtual Tour:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;"><a href="#">view tour...</a></td>
                   <td style="text-align:right;font-size:small;font-weight:bold;">Email:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;"><a href="#">admin@fllakehouse.com</a></td>
                </tr>
                <tr>

                   <td style="text-align:right;font-size:small;font-weight:bold;">Map Property:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;"><a href="#">google</a>&nbsp;|&nbsp;<a href="#">yahoo</a>&nbsp;|&nbsp;<a href="#">mapquest</a></td>
                   <td style="text-align:right;font-size:small;font-weight:bold;">Contact:</td>
                   <td style="text-align:left;font-size:small;font-weight:normal;"><a href="#">request more info</a>...</td>

                </tr>
            </table>
            </td>                       
        </tr>

        <tr>
            <td colspan="6" align="left" valign="top" style=""><p style="margin-left:10px;margin-right:10px;"><strong>Description:</strong> This Lake Keystone home is situated on a large corner lot that just falls short of one acre. This lot contains large beautiful oaks and has 170ft of water frontage. There is plenty of room for parking on the brand new U-shaped asphalt driveway. New windows, a new roof and new paint give this house a great curb appeal. The entire house has been completely renovated!!! Renovations include large 18 inch tile, carpet, and window treatments throughout. Two Rheem units and new ducting complete an entirely new cooling and heating system with touch screen thermostats. The kitchen features all wood cabinets, blue pearl granite, and high end stainless steal appliances. You will get a WOW out of everyone who sees the bathroom vanities; also with granite countertops. The master bathroom is superior to most; the floors and shower walls are covered in natural stone (travertine). The gigantic shower contains four shower heads with majestic marble medallions on each shower wall. The large walk in closet with cherry wood finish organizer provides ample room for his and her attire. After sun bathing in the large screened in pool, take a walk down to the new dock to feed the fish and turtle friends who eagerly wait to see you each day.</p>

            </td>                       
        </tr>


                
    </table>
    </div>
<!-- ------- Main Content End ---------------------------------------------------------- -->    

	</div>
	
<? include ('includes/leftCol.php') ?>	
<? include ('includes/rightCol.php') ?>
<? include ('includes/footer.php') ?>
