<? include ('includes/headA.php') ?>

	<div id="body">
		<!-- ------- Main Content Start ---------------------------------------------------------- -->    
    <div id="mainCol">
      <table align="center">
        <tr>
          <td colspan="2"><h2>Florida Featured Lakefronts</h2>
            <p>Our passion and energy revolves around Florida�s lakefront enthusiasts with the Florida�s #1 connection to lakefront homes and lakefront lots. Buying and selling lakefront property is an art and requires an inner passion and understanding for lakefront enthusiasts.</p></td>
        </tr>
        
        
        
        <tr>
          <td colspan="2">
		  <table style="width: 100%;" bgcolor="green" cellpadding="0" cellspacing="0">
                <tr>
	 			  <td><h3>Odessa <span><em>Featured Property</em></span></h3></td>
                  <td><h3><span><a href="#" class="moreCity">[ View All Odessa Lakefront ]</a></span> </td>
                </tr>
            </table>
            <table style="width: 100%; background: transparent url(images/premierebg.jpg) top left repeat-x;" cellpadding="0" cellspacing="0">
                <tr>
                  <td><img class="featured" src="images/Autumnslisting.jpg" width="167" height="129"></td>
                  <td>
                    <table id="listing">
					  	<tr>
						  <td colspan="6" align="left"><h4>Offered at: <span class="price">$1,250,000</span></h4></td></tr>
                        <tr>
                          <td style="height: 17px;" align="center">Acres</td>
                          <td style="height: 17px;" align="center">Sqft</td>
                          <td style="height: 17px;" align="center">Beds</td>
                          <td style="height: 17px;" align="center">Baths</td>
                          <td style="height: 17px;" align="center">Garage</td>
                          <td style="height: 17px;" align="center">Pool</td>
                        </tr>
                        <tr>
                          <td style="height: 17px;" align="center">1 - 2</td>
                          <td style="height: 17px;" align="center">2480</td>
                          <td style="height: 17px;" align="center">4</td>
                          <td style="height: 17px;" align="center">2</td>
                          <td style="height: 17px;" align="center">2</td>
                          <td style="height: 17px;" align="center">Yes</td>
                        </tr>
						<tr>
						<td colspan="6" align="left" class="description">
						<p>Spectacular home built in 2007 by Lee Fernandez. This masterpiece is one of a kind, boasting all kinds of neat stuff. You can't find a better house than this so come see it today.&nbsp; If you cant don't like what you see, then go home peanut...</p>
						</td></tr>
                    </table>
					</td>
                </tr>
                <tr>
                  <td align="center">&nbsp;</td>
                  <td align="right" style="padding-right: 10px;"><em><a href="featured-lakefront-detail.php">...more info on this property</a></em> </td>
                </tr>
            </table><br />
            </td>
        </tr>
        
        
        
        <tr>
          <td colspan="2">
		  <table style="width: 100%;" bgcolor="green" cellpadding="0" cellspacing="0">
                <tr>
	 			  <td><h3>Odessa <span><em>Featured Property</em></span></h3></td>
                  <td><h3><span><a href="#" class="moreCity">[ View All Odessa Lakefront ]</a></span> </td>
                </tr>
            </table>
            <table style="width: 100%; background: transparent url(images/premierebg.jpg) top left repeat-x;" cellpadding="0" cellspacing="0">
                <tr>
                  <td><img class="featured" src="images/Autumnslisting.jpg" width="167" height="129"></td>
                  <td>
                    <table id="listing">
					  	<tr>
						  <td colspan="6" align="left"><h4>Offered at: <span class="price">$1,250,000</span></h4></td></tr>
                        <tr>
                          <td style="height: 17px;" align="center">Acres</td>
                          <td style="height: 17px;" align="center">Sqft</td>
                          <td style="height: 17px;" align="center">Beds</td>
                          <td style="height: 17px;" align="center">Baths</td>
                          <td style="height: 17px;" align="center">Garage</td>
                          <td style="height: 17px;" align="center">Pool</td>
                        </tr>
                        <tr>
                          <td style="height: 17px;" align="center">1 - 2</td>
                          <td style="height: 17px;" align="center">2480</td>
                          <td style="height: 17px;" align="center">4</td>
                          <td style="height: 17px;" align="center">2</td>
                          <td style="height: 17px;" align="center">2</td>
                          <td style="height: 17px;" align="center">Yes</td>
                        </tr>
						<tr>
						<td colspan="6" align="left" class="description">
						<p>Spectacular home built in 2007 by Lee Fernandez. This masterpiece is one of a kind, boasting all kinds of neat stuff. You can't find a better house than this so come see it today.&nbsp; If you cant don't like what you see, then go home peanut...</p>
						</td></tr>
                    </table>
					</td>
                </tr>
                <tr>
                  <td align="center">&nbsp;</td>
                  <td align="right" style="padding-right: 10px;"><em><a href="featured-lakefront-detail.php">...more info on this property</a></em> </td>
                </tr>
            </table><br />
            </td>
        </tr>
        
        <tr>
          <td colspan="2">
		  <table style="width: 100%;" bgcolor="green" cellpadding="0" cellspacing="0">
                <tr>
	 			  <td><h3>Odessa <span><em>Featured Property</em></span></h3></td>
                  <td><h3><span><a href="#" class="moreCity">[ View All Odessa Lakefront ]</a></span> </td>
                </tr>
            </table>
            <table style="width: 100%; background: transparent url(images/premierebg.jpg) top left repeat-x;" cellpadding="0" cellspacing="0">
                <tr>
                  <td><img class="featured" src="images/Autumnslisting.jpg" width="167" height="129"></td>
                  <td>
                    <table id="listing">
					  	<tr>
						  <td colspan="6" align="left"><h4>Offered at: <span class="price">$1,250,000</span></h4></td></tr>
                        <tr>
                          <td style="height: 17px;" align="center">Acres</td>
                          <td style="height: 17px;" align="center">Sqft</td>
                          <td style="height: 17px;" align="center">Beds</td>
                          <td style="height: 17px;" align="center">Baths</td>
                          <td style="height: 17px;" align="center">Garage</td>
                          <td style="height: 17px;" align="center">Pool</td>
                        </tr>
                        <tr>
                          <td style="height: 17px;" align="center">1 - 2</td>
                          <td style="height: 17px;" align="center">2480</td>
                          <td style="height: 17px;" align="center">4</td>
                          <td style="height: 17px;" align="center">2</td>
                          <td style="height: 17px;" align="center">2</td>
                          <td style="height: 17px;" align="center">Yes</td>
                        </tr>
						<tr>
						<td colspan="6" align="left" class="description">
						<p>Spectacular home built in 2007 by Lee Fernandez. This masterpiece is one of a kind, boasting all kinds of neat stuff. You can't find a better house than this so come see it today.&nbsp; If you cant don't like what you see, then go home peanut...</p>
						</td></tr>
                    </table>
					</td>
                </tr>
                <tr>
                  <td align="center">&nbsp;</td>
                  <td align="right" style="padding-right: 10px;"><em><a href="featured-lakefront-detail.php">...more info on this property</a></em> </td>
                </tr>
            </table><br />
            </td>
        </tr>
        
        
        </table>
    </div>
<!-- ------- Main Content End ---------------------------------------------------------- -->    

	</div>
	
<? include ('includes/leftCol.php') ?>	
<? include ('includes/rightCol.php') ?>
<? include ('includes/footer.php') ?>




