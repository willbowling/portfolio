<? include ('includes/headA.php') ?>

	<div id="body">


    <div id="mainCol">
<table align="center">
<tr>
	<td colspan="2"><h2>Welcome to Florida Lakehouse!</h2><p>Our passion and energy revolves around Florida�s lakefront enthusiasts with the Florida�s #1 connection to lakefront homes and lakefront lots. Buying and selling lakefront property is an art and requires an inner passion and understanding for lakefront enthusiasts.</p></td>
</tr>
<tr>
	<td colspan="2">
	<div id="premiere">
        <h3>TAMPA <span><em>Premiere Property</em></span></h3>
        <img class="premiereImg" src="images/Autumnslisting.jpg" width="167" height="129" align="left" style="margin: 0 15px;" />
        <p>This beautiful lakehouse is located on a prestine lakefront property, nestled into a country setting.</p>
        <p><a href="#">View All Tampa Premiere Properties</a></p>
   </div>
    <div id="premiere">
        <h3>ODESSA <span><em>Premiere Property</em></span></h3>
        <img class="premiereImg" src="images/Autumnslisting.jpg" width="167" height="129" align="left" style="margin: 0 15px;" />
        <p>This beautiful lakehouse is located on a prestine lake property, nestled into a country setting.</p>
        <p><a href="#">View All Odessa Premiere Properties</a></p>
    </div>
    <div id="premiere">
        <h3>LAKE KEYSTONE <span><em>Premiere Property</em></span></h3>
        <img class="premiereImg" src="images/Autumnslisting.jpg" width="167" height="129" align="left" style="margin: 0 15px;" />
        <p>This beautiful lakehouse is located on a prestine lakefront property, nestled into a country setting.</p>
        <p><a href="#">View All Lake Keystone Premiere Properties</a></p>
    </div>
 	</td>
 </tr>
 </table>
  </div>
    
<!-- ------- Main Content End ---------------------------------------------------------- -->    

	</div>
	
<? include ('includes/leftCol.php') ?>	
<? include ('includes/rightCol.php') ?>
<? include ('includes/footer.php') ?>


