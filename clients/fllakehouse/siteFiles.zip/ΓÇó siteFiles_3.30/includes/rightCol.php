<!-- ------- Right Col Start ---------------------------------------------------------- -->
    <div id="rightCol">
      <div id="inner">
        <h3 class="topHead">Up Close</h3>
        <div align="center"><img src="images/chris_johnson.jpg" /></div>
        <br />
        <p>Hi my name is Chris Johnson and I am here to help you find the perfect Lakefront Property</p>
        <p>Please fill out the simple form below for more information</p>
        <form action="" method="post">
          <table align="center">
            <tr>
              <td width="55"><label>Name</label></td>
              <td width="90"><input type="text" style="width: 90px; border: 1px solid gray" /> </td>
            </tr>
            <tr>
              <td><label>Email</label></td>
              <td><input type="text" style="width: 90px; border: 1px solid gray" /> </td>
            </tr>
            <tr>
              <td><label>Phone</label></td>
              <td><input type="text" style="width: 90px; border: 1px solid gray" /> </td>
            </tr>
            <tr>
              <td colspan="2"><label>Comments</label></td>
            </tr>
            <tr></tr>
            <tr>
              <td colspan="2"><textarea  style="width: 150px;" rows="4" />
                </textarea></td>
            <tr>
              <td colspan="2" align="center">
              <input type="submit" class="formbutton" value="Submit" /></td>
            </tr>
          </table>
        </form>
      </div>
      <h4><span>Florida Lakefront Quick Links</span></h4>
    </div>
<!-- ------- Right Col End ---------------------------------------------------------- -->