<!-- ------- Footer Start ---------------------------------------------------------- -->    
	<div id="footer">
	<p align="center">Chris Johnson .: 5555 Odessa Lane .: Odessa, FL 33635</p>
	<p align="center">&copy; Copyright 2007 .: All Rights Reserved .: Site Design by <a href="http://www.willbowling.com">Will Bowling</a></p>
	<br>
	</div>

</div>
</body>
</html>
