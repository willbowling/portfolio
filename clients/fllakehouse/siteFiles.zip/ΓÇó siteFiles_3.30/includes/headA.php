<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Expires" content="-1" />
	<meta http-equiv="pragma" content="no-cache" />
	<meta name="ROBOTS" content="ALL" />
	<meta name="author" content="Will Bowling :: http://www.Willbowling.com " />
	<meta name="Keywords" content="florida lakefront property, florida lakefront property for sale, Odessa, Tampa, Lake Keystone, Orlando, Lakefront, Lake Home, Lakeside, listings" />
	<meta name="Description" content=" ______ " />

	<link href="css/florida-lakehouse.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="screen" />

	<title> Florida Lake House .: Lake front properties in Odessa, Orlando, Tampa, Lakeland Florida </title> 
<!--[if IE]>
<style type="text/css">
.ddoverlap{
height: 1%;  /*Apply Holly 3px jog hack to get IE to position bottom border correctly beneath the menu*/
}

</style>
<![endif]-->
<script src="js/prototype.js" type="text/javascript"></script> <script src="js/scriptaculous.js?load=effects" type="text/javascript"></script> <script src="js/lightbox.js" type="text/javascript"></script> 
</head>
<body>
<div id="wrapper">
	<div id="head">
		<h1> <span> Florida Lake House .: Lake front properties in Odessa, Orlando, Tampa, Lakeland Florida</span> </h1> 
		<div class="ddoverlap">
			<ul>
				<li>
					<a href="index.php"> Home </a> 
				</li>
				<li>
					<a href="featured-lakefront.php"> Featured Lakefront </a> 
				</li>
				<li>
					<a href="#"> Search Lake Homes </a> 
				</li>
				<li>
					<a href="#"> Popular Florida Lakes </a> 
				</li>
				<li>
					<a href="#"> Frequent Questions </a> 
				</li>
				<li>
					<a href="#"> About Us </a> 
				</li>
				<li>
					<a href="#"> Contact Us </a> 
				</li>
			</ul>
			<br style="clear: left" />
		</div>
	</div>
	