<!-- ------- Left Nav Start ---------------------------------------------------------- -->
    <div id="leftCol">
      <div id="inner">
        <h3 class="topHead">Search Tampa Area</h3>
        <ul>
          <li><a href="#">Featured LakeFront</a></li>
          <li><a href="#">MLS Listings</a></li>
          <li><a href="#">Popular Lakes</a></li>
          <li><a href="#">Citrus County</a></li>
          <li><a href="#">Hillsborough County</a></li>
          <li><a href="#">Pasco County</a></li>
          <li><a href="#">Polk County</a></li>          
        </ul>
        <h3>Search Orlando Area</h3>
        <ul>
          <li><a href="#">Featured LakeFront</a></li>
          <li><a href="#">MLS Listings</a></li>
          <li><a href="#">Popular Lakes</a></li>
          <li><a href="#">Lake County</a></li>
          <li><a href="#">Orange County</a></li>
		  <li><a href="#">Osceola County</a></li>
		  <li><a href="#">Seminole County</a></li>
		  <li><a href="#">Sumter County</a></li>
		  <li><a href="#">Volusia County</a></li>
        </ul>
        <h3>Buy/Sell Lakefront</h3>
        <ul>
          <li><a href="#">FREE Advertising</a></li>
          <li><a href="#">Help Me Sell!</a></li>
          <li><a href="#">Help Me Buy!</a></li>
        </ul>
      </div>
      <h4><span>Florida Lakefront Quick Links</span></h4>
    </div>
<!-- ------- Left Nav End ---------------------------------------------------------- -->