<? include ('includes/headA.php') ?>

	<div id="body">


  <div id="mainCol">

<h3>View Popular Florida Lakes</h3>
<p style="margin-bottom: 400px;">Select a Metro Area: 
<span>
	<form>
	<select>
		<option value=""> --- </option>
		<option value="Tampa"> Tampa </option>
		<option value="Orlando"> Orlando </option>
	</select>
</span>
</p>

  </div>
    
<!-- ------- Main Content End ---------------------------------------------------------- -->    

	</div>
	
<? include ('includes/leftCol.php') ?>	
<? include ('includes/rightCol.php') ?>
<? include ('includes/footer.php') ?>


